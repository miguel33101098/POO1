import javax.swing.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {
    private JTextField userField;
    private JPasswordField passField;
    private JButton loginButton;

    public LoginFrame() {
        setTitle("Login");
        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel userLabel = new JLabel("Usuario:");
        userLabel.setBounds(10, 10, 80, 25);
        add(userLabel);

        userField = new JTextField();
        userField.setBounds(100, 10, 160, 25);
        add(userField);

        JLabel passLabel = new JLabel("Contraseña:");
        passLabel.setBounds(10, 40, 80, 25);
        add(passLabel);

        passField = new JPasswordField();
        passField.setBounds(100, 40, 160, 25);
        add(passField);

        loginButton = new JButton("Iniciar sesión");
        loginButton.setBounds(100, 80, 160, 25);
        add(loginButton);

        loginButton.addActionListener(e -> {
            String user = userField.getText();
            String pass = new String(passField.getPassword());
            if (controlador.AuthController.login(user, pass)) {
                JOptionPane.showMessageDialog(this, "Bienvenido!");
                dispose(); // cerrar login
                new DashboardFrame().setVisible(true); // abrir menú principal
            } else {
                JOptionPane.showMessageDialog(this, "Credenciales incorrectas.");
            }
        });
    }
}
