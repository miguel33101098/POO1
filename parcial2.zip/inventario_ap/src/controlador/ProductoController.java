package controlador;

import modelo.Producto;
import java.util.ArrayList;

public class ProductoController {
    private static ArrayList<Producto> productos = new ArrayList<>();

    public static boolean crearProducto(Producto p) {
        productos.add(p);
        return true;
    }

    public static ArrayList<Producto> obtenerProductos() {
        return productos;
    }
}
