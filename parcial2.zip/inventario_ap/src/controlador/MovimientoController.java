package controlador;

import java.util.Scanner;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Producto;

public class MovimientoController {
    private ArrayList<Producto> productos;

    public MovimientoController(ArrayList<Producto> productos) {
        this.productos = productos;
    }

   public void registrarEntradaGUI() {
    if (productos.isEmpty()) {
        JOptionPane.showMessageDialog(null, "⚠️ No hay productos registrados.");
        return;
    }

    // Crear combo con productos
    Producto seleccionado = (Producto) JOptionPane.showInputDialog(
        null,
        "Seleccione un producto:",
        "📥 Registrar Entrada",
        JOptionPane.QUESTION_MESSAGE,
        null,
        productos.toArray(),
        productos.get(0)
    );

    if (seleccionado != null) {
        String cantidadStr = JOptionPane.showInputDialog("Cantidad a ingresar:");
        try {
            int cantidad = Integer.parseInt(cantidadStr);
            seleccionado.setCantidad(seleccionado.getCantidad() + cantidad);
            JOptionPane.showMessageDialog(null, "✅ Entrada registrada. Nuevo stock: " + seleccionado.getCantidad());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "❌ Cantidad inválida.");
        }
    }
}


    public void registrarSalidaGUI() {
    if (productos.isEmpty()) {
        JOptionPane.showMessageDialog(null, "⚠️ No hay productos registrados.");
        return;
    }

    Producto seleccionado = (Producto) JOptionPane.showInputDialog(
        null,
        "Seleccione un producto:",
        "📤 Registrar Salida",
        JOptionPane.QUESTION_MESSAGE,
        null,
        productos.toArray(),
        productos.get(0)
    );

    if (seleccionado != null) {
        String cantidadStr = JOptionPane.showInputDialog("Cantidad a descontar:");
        try {
            int cantidad = Integer.parseInt(cantidadStr);
            if (cantidad > seleccionado.getCantidad()) {
                JOptionPane.showMessageDialog(null, "❌ No hay suficiente stock.");
            } else {
                seleccionado.setCantidad(seleccionado.getCantidad() - cantidad);
                JOptionPane.showMessageDialog(null, "✅ Salida registrada. Nuevo stock: " + seleccionado.getCantidad());
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "❌ Cantidad inválida.");
        }
    }
}


    private void listarProductos() {
        for (int i = 0; i < productos.size(); i++) {
            Producto p = productos.get(i);
            System.out.println(i + ". " + p.getNombre() + " (" + p.getCantidad() + ")");
        }
    }

}