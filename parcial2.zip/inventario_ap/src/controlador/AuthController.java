package controlador;

import config.ConexionBD;
import java.sql.*;

public class AuthController {
    public static boolean login(String usuario, String clave) {
        try (Connection conn = ConexionBD.conectar()) {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM usuarios WHERE username=? AND password=?");
            stmt.setString(1, usuario);
            stmt.setString(2, clave);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

