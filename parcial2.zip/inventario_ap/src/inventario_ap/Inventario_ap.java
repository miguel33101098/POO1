import controlador.AuthController;
import controlador.ProductoController;
import controlador.MovimientoController;
import modelo.Producto;

import javax.swing.*;
import java.util.ArrayList;

public class Inventario_ap {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            loginYMostrarMenu();
        });
    }

    private static void loginYMostrarMenu() {
        String user = JOptionPane.showInputDialog(null, "Usuario:");
        String pass = JOptionPane.showInputDialog(null, "Contraseña:");

        if (AuthController.login(user, pass)) {
            JOptionPane.showMessageDialog(null, "✅ Bienvenido al sistema de inventario. SAS");

            ArrayList<Producto> productos = ProductoController.obtenerProductos();
            MovimientoController movimientoController = new MovimientoController(productos);

            boolean salir = false;
            while (!salir) {
                String[] opciones = {
                    "1. Crear producto",
                    "2. Registrar entrada",
                    "3. Registrar salida",
                    "4. Ver productos",
                    "5. Salir"
                };

                String opcionSeleccionada = (String) JOptionPane.showInputDialog(
                        null,
                        "Seleccione una opción:",
                        "📋 Menú Principal",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        opciones,
                        opciones[0]
                );

                if (opcionSeleccionada == null) break;

                switch (opcionSeleccionada.charAt(0)) {
                    case '1': {
                        String nombre = JOptionPane.showInputDialog("Nombre del producto:");
                        String categoria = JOptionPane.showInputDialog("Categoría:");
                        String cantidadStr = JOptionPane.showInputDialog("Cantidad inicial:");
                        int cantidad = Integer.parseInt(cantidadStr);

                        Producto nuevo = new Producto(nombre, categoria, cantidad);
                        if (ProductoController.crearProducto(nuevo)) {
                            productos.add(nuevo);
                            JOptionPane.showMessageDialog(null, "✅ Producto creado exitosamente.");
                        } else {
                            JOptionPane.showMessageDialog(null, "❌ Error al crear el producto.");
                        }
                        break;
                    }

                    case '2':
                        movimientoController.registrarEntradaGUI();
                        break;

                    case '3':
                        movimientoController.registrarSalidaGUI();
                        break;

                    case '4': {
                        StringBuilder sb = new StringBuilder();
                        for (Producto p : productos) {
                            sb.append("📦 ")
                              .append(p.getNombre()).append(" | ")
                              .append(p.getCategoria()).append(" | Stock: ")
                              .append(p.getCantidad()).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, sb.toString(), "Productos", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    }

                    case '5':
                        salir = true;
                        break;

                    default:
                        JOptionPane.showMessageDialog(null, "⚠️ Opción inválida.");
                }
            }

        } else {
            JOptionPane.showMessageDialog(null, "❌ Credenciales incorrectas.");
        }
    }
}
