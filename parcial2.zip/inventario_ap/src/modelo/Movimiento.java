package modelo;

public class Movimiento {
    private String tipo;
    private String producto;
    private int cantidad;

    public Movimiento(String tipo, String producto, int cantidad) {
        this.tipo = tipo;
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public String getTipo() {
        return tipo;
    }

    public String getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }
}
